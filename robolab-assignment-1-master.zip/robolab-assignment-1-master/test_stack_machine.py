#!/usr/bin/env python3

class TestStackMachine:
    def test_instance(self):
        """ Essential: Test class instantiation """
        self.fail('implement me!')

    """ Please add your test cases here! """
