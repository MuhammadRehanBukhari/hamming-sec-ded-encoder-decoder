# Documentation

> Author: Samuel Leo

## Internal Stack

The pre-defined `Stack` class provides an 8-bit LIFO stack capable of storing:
- 8-bit unsigned integers
- single characters
- c_ubyte type

In order to interact with the stack the following methods are available:
- push() - Adds an item to the stack
- pop()  - Removes and returns the most-top item from the stack
- peek() - Shows the most-top item of the stack

Besides the above, a custom error `StackError` is provided to give information while working with the stack.
